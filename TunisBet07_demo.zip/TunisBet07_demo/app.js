const translations = {
  ar: {
    home:"الرئيسية",sports:"الرياضات",results:"النتائج",eyebrow:"منصتك الرياضية التجريبية",
    heroTitle:"عِش أجواء الرياضة<br><em>بأسلوب جديد</em>",heroText:"واجهة تجريبية لـ TunisBet07 باللغتين العربية والفرنسية. لا توجد رهانات أو معاملات مالية حقيقية.",
    viewMatches:"استكشف المباريات",discover:"اكتشف",sportsTitle:"الرياضات",demoContent:"محتوى توضيحي",
    football:"كرة القدم",basketball:"كرة السلة",tennis:"التنس",volleyball:"الكرة الطائرة",
    spotlight:"في الواجهة",matchesTitle:"مباريات تجريبية",notLive:"ليست مباشرة",
    league1:"مثال توضيحي · دوري تجريبي",league2:"مثال توضيحي · كأس تجريبي",
    fictional:"مباراة خيالية لأغراض التصميم فقط",demoNoticeTitle:"نسخة تجريبية فقط",
    demoNotice:"لا تتضمن هذه النسخة تسجيل حسابات أو إيداعاً أو سحباً أو رهانات أو احتمالات حقيقية.",
    yourBrand:"هويتك",brandText:"تصميم أولي قابل للتطوير بعد استكمال المراجعات القانونية والتقنية اللازمة.",
    bilingual:"عربي وفرنسي",bilingualText:"تبديل اللغة واتجاه العرض بضغطة واحدة.",
    responsive:"متوافق مع الهاتف",responsiveText:"تصميم مرن للشاشات الصغيرة والكبيرة.",
    footer:"واجهة تجريبية غير مخصصة لقبول الأموال أو تشغيل المراهنات."
  },
  fr: {
    home:"Accueil",sports:"Sports",results:"Résultats",eyebrow:"Votre interface sportive de démonstration",
    heroTitle:"Vivez le sport<br><em>autrement</em>",heroText:"Prototype TunisBet07 en arabe et en français. Aucun pari ni aucune transaction financière réelle.",
    viewMatches:"Voir les matchs",discover:"Découvrir",sportsTitle:"Sports",demoContent:"Contenu fictif",
    football:"Football",basketball:"Basket",tennis:"Tennis",volleyball:"Volley",
    spotlight:"À la une",matchesTitle:"Matchs de démonstration",notLive:"Pas en direct",
    league1:"Exemple fictif · Ligue démo",league2:"Exemple fictif · Coupe démo",
    fictional:"Match fictif utilisé uniquement pour la maquette",demoNoticeTitle:"Version de démonstration",
    demoNotice:"Cette version ne propose ni comptes joueurs, ni dépôts, ni retraits, ni paris, ni cotes réelles.",
    yourBrand:"Votre marque",brandText:"Maquette initiale à faire évoluer après les vérifications juridiques et techniques nécessaires.",
    bilingual:"Arabe et français",bilingualText:"Changez la langue et le sens d’affichage en un clic.",
    responsive:"Adapté au mobile",responsiveText:"Une mise en page adaptée aux petits et grands écrans.",
    footer:"Prototype non destiné à accepter de l'argent ni à exploiter des paris."
  }
};
let current = "ar";
const button = document.getElementById("langToggle");
function setLanguage(lang) {
  current = lang;
  document.documentElement.lang = lang;
  document.documentElement.dir = lang === "ar" ? "rtl" : "ltr";
  document.body.dir = lang === "ar" ? "rtl" : "ltr";
  document.querySelectorAll("[data-i18n]").forEach(el => {
    const key = el.dataset.i18n;
    if (translations[lang][key]) el.innerHTML = translations[lang][key];
  });
  button.textContent = lang === "ar" ? "FR" : "ع";
}
button.addEventListener("click", () => setLanguage(current === "ar" ? "fr" : "ar"));
setLanguage("ar");
